function solve() {

    //TODO...
}
